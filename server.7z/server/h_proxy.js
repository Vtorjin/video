const express = require('express');
const cors = require('cors');
const app = express();
const port = 7020;
const request = require("request");
const map = new Map();
const cheerio = require('cheerio');
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');
const httpProxy = require('http-proxy');
var list = [
]

function extractResourceLinks(htmlText, rootPath) {
    // 匹配HTML标签中的src和href属性值
    var regex = /(?:src|href)=(?:"([^"]+)"|'([^']+)'|([^'"\s>]+))/ig;
    var matches;
    var resourceLinks = [];
    while ((matches = regex.exec(htmlText)) !== null) {
        var link = matches[1] || matches[2] || matches[3];

        // 判断链接是否以http开头，如果是则直接加入列表，否则拼接为完整的地址
        if (link.startsWith("http")) {
            resourceLinks.push(link);
        } else {
            // 拼接根路径和相对路径
            var fullLink = rootPath + "/" + link;
            resourceLinks.push(fullLink);
        }
    }

    return resourceLinks;
}


class ConcurrentRequestManager {
    constructor(maxConcurrentRequests) {
        this.maxConcurrentRequests = maxConcurrentRequests;
        this.taskQueue = [];

    }
    async run() {
        if (this.taskQueue.length == 0) return;
        const min = Math.min(this.taskQueue.length, this.maxConcurrentRequests);
        for (var i = 0; i < min; i++) {
            this.max--; // 执行最大并发递减  
            var task = this.taskQueue.shift(); // 从数组头部取任务  
            task().then((res) => { // 重：此时可理解为，当for循环执行完毕后异步请求执行回调,此时max变为0  
                console.log(res)
                const { host, address, delay } = res;
                document.querySelector(`span[data-id="${host}"]`).innerText = address.slice(address.indexOf('来自于:') + 4);
                document.querySelector(`span[data-delay="${host}"]`).innerText = delay;

            }).finally(() => { // 重：当所有请求完成并返回结果后，执行finally回调，此回调将按照for循环依次执行，此时max为0.  
                this.max++; // 超过最大并发10以后的任务将按照任务顺序依次执行。此处可理解为递归操作。  
                this.run();
            })
        }
    }

    async sendRequest(ip) {
        return new Promise((resolve, reject) => {
            // 在这里执行发送请求的逻辑
            setTimeout(() => {
                console.log(`请求完成：${ip.host}:${ip.port}`);
                resolve(ip);
            }, 1000); // 模拟一个异步请求
        });
    }

    async controlConcurrentRequests() {
        let currentIndex = 0;

        while (currentIndex < this.waitQueue.length) {
            if (this.inProgress.length < this.maxConcurrentRequests) {
                const ip = this.waitQueue[currentIndex++];
                const requestPromise = this.sendRequest(ip);
                this.inProgress.push(requestPromise);

                requestPromise.then(() => {
                    // 请求完成后，从inProgress数组中移除
                    const index = this.inProgress.indexOf(requestPromise);
                    if (index !== -1) {
                        this.inProgress.splice(index, 1);
                    }
                });
            } else {
                // 等待当前请求数达到最大并发数
                await Promise.race(this.inProgress);
            }
        }

        // 等待所有请求完成
        await Promise.all(this.inProgress);
        console.log('所有请求已完成');
    }

    addToQueue(fn) {
        this.taskQueue.push(fn);
    }
}



// 使用CORS中间件处理跨域请求
app.use(cors());

// 使用Express内置的中间件解析JSON请求体
app.use(express.json());

// app.use('/',(req,res)=>{
//     res.send('ok!')
// })

// 示例数据：待办事项数组
const todos = [
    { id: 1, text: '完成任务1', done: false },
    { id: 2, text: '完成任务2', done: true },
];

// 获取所有待办事项
app.get('/todos', (req, res) => {
    res.json(todos);
});

app.get('/ip', (req, res) => {
    var { ip, port, password, username } = req.query;
    var targetOptions = {
        method: 'GET',
        // url: 'http://myip.ipip.net',
        timeout: 8000,
        encoding: null,
        proxy: `http://${ip}:${port}`,
        headers: {
            'Proxy-Authorization': 'Basic ' + Buffer.from('qwe1qwe1qwe1:qwe1qwe1qwe1', 'utf-8').toString('base64'),
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'zh-CN,zh;q=0.8,en;q=0.6,zh-TW;q=0.4',
            'User-Agent': 'Mozilla/8.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36',
        }
    };
    var delay = Date.now()
    request(targetOptions, function (error, response, body) {
        try {
            if (body) {
                body = body.toString();
                var $ = cheerio.load(body);
                console.log('有效的ip', targetOptions.proxy, $('script'));
                res.send({
                    data: body,
                    // data: '',
                    delay: Date.now() - delay
                });
            } else {
                res.send({
                    data: '匹配失败!',
                    delay: Date.now() - delay
                });
            }

        } catch (e) {
            console.error('失败了哟!', e, targetOptions.headers);
            res.send({
                data: '匹配失败!',
                delay: Date.now() - delay
            });
        }
    })
    // res.send({
    //     q: ip,
    //     t: port,
    //     p: password,
    //     n: username
    // });
})

app.get('/url', (req, res) => {
    var { ip, port, password, username } = req.query;
    var delay = Date.now()
    let targetUrl = "";

    var targetOptions = {
        method: 'GET',
        // url: 'http://myip.ipip.net',
        url: targetUrl,
        timeout: 30000,
        changeOrigin: true,
        // encoding: null,
        proxy: `http://${ip}:${port}`,
        headers: {
            'Proxy-Authorization': 'Basic ' + Buffer.from('qwe1qwe1qwe1:qwe1qwe1qwe1', 'utf-8').toString('base64'),
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
        }
    };

    request(targetOptions, function (error, response, body) {
        try {
            if (body) {
                var $ = cheerio.load(body);
                console.log('有效的ip', targetOptions.proxy);

                // extractResourceLinks(body, targetUrl)
                // res.setHeader('Content-Type', 'text/html;charset=utf-8')
                res.send(body);
            } else {
                console.log(error, ip, port)
                res.send('匹配失败!');
            }

        } catch (e) {
            console.error('失败了哟!', e, targetOptions.headers);
            res.send({
                data: '匹配失败!',
                delay: Date.now() - delay
            });
        }
    })
})

app.get('/proxy', (req, res) => {
    req.headers = {
        ...req.headers,
        'Proxy-Authorization': 'Basic ' + Buffer.from('qwe1qwe1qwe1:qwe1qwe1qwe1', 'utf-8').toString('base64'),
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
    }

 

 
    httpProxy.createProxyServer({
        timeout: 20000,
        proxy: "http://23.236.222.201:7232",
        headers: {
            ...req.headers,
            'Proxy-Authorization': 'Basic ' + Buffer.from('qwe1qwe1qwe1:qwe1qwe1qwe1', 'utf-8').toString('base64'),
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
        },
        changeOrigin: true,
    }).web(req, res, { target: "http://104.239.3.9:5969" });
})

function downloadFile(fileUrl, ip, port) {
    if (fileUrl == undefined) return;
    // console.log('开始的fileUrl');
    const parsedUrl = url.parse(fileUrl);
    const filePath = parsedUrl.pathname.split('/').slice(3, -1).join('/');
    const fileName = path.basename(parsedUrl.pathname).split('?')[0];
    const folderPath = path.join(__dirname, 'recipes', 'telegram', filePath);
    const filePathOnDisk = path.join(folderPath, fileName);

    if (fs.existsSync(filePathOnDisk) && fs.statSync(filePathOnDisk).size !== 0) {
        return next();
    }

    // 创建文件夹
    fs.mkdirSync(folderPath, { recursive: true });
    const targetUrl = fileUrl;
    var targetOptions = {
        method: 'GET',
        url: targetUrl,
        timeout: 30000,
        // encoding: null,
        proxy: `http://${ip}:${port}`,
        headers: {
            'Proxy-Authorization': 'Basic ' + Buffer.from('qwe1qwe1qwe1:qwe1qwe1qwe1', 'utf-8').toString('base64'),
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
        }
    };

    function next() {
        list.length && downloadFile(list.shift(), ip, port)
    }

    if (/\.js|\.css|\.html|\.json/.test(filePathOnDisk)) {
        request(targetOptions, function (error, response, body) {
            if (body) {
                fs.writeFileSync(filePathOnDisk, body);
                next();
                console.log(`文件已下载到 ${filePathOnDisk}`);
            } else {
                !list.includes(fileUrl) && list.push(fileUrl)
                next()
            }
        })

    } else {
        request(targetOptions).on('error', (err) => {
            // console.error('下载图片时出错:', err);
            !list.includes(fileUrl) && list.push(fileUrl)
            next();
        }).pipe(fs.createWriteStream(filePathOnDisk))
            .on('close', () => {
                console.log('媒体资源下载完成！');
                next()
            });
    }
}

downloadFile(list.pop(), '23.236.222.201', 7232)

// 获取单个待办事项
app.get('/todos/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const todo = todos.find((item) => item.id === id);

    if (!todo) {
        res.status(404).json({ message: '待办事项未找到' });
    } else {
        res.json(todo);
    }
});

// 创建新待办事项
app.post('/todos', (req, res) => {
    const newTodo = req.body;
    newTodo.id = todos.length + 1;
    todos.push(newTodo);
    res.status(201).json(newTodo);
});

// 更新待办事项
app.put('/todos/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const updatedTodo = req.body;
    const index = todos.findIndex((item) => item.id === id);

    if (index === -1) {
        res.status(404).json({ message: '待办事项未找到' });
    } else {
        todos[index] = updatedTodo;
        res.json(updatedTodo);
    }
});

// 删除待办事项
app.delete('/todos/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = todos.findIndex((item) => item.id === id);

    if (index === -1) {
        res.status(404).json({ message: '待办事项未找到' });
    } else {
        const deletedTodo = todos.splice(index, 1);
        res.json(deletedTodo[0]);
    }
});

app.get('/load', (req, res) => {
    var { ip, port } = req.query;
    downloadFile(list.shift(), ip, port)
    res.send('下载中')
})

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});


process.on('uncaughtException', () => {

})
process.on('unhandledRejection', () => {

})