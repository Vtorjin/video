const http = require('http'),
    httpProxy = require('http-proxy');
 
//
// 使用自定义应用程序逻辑创建代理服务器
//
const proxy = httpProxy.createProxyServer({});
 
//
// 创建您的自定义服务器，只需调用 `proxy.web()` 来代理
// 发送给目标的web请求传递在选项中
// 同样的，也可以使用`proxy.ws()`
//
const server = http.createServer(function(req, res) {
  // 你可以在这里添加处理逻辑
  // proxy.web(req, res, { target: 'http://140.99.86.171:8281/' });
  proxy.web(req, res, { target: 'http://120.79.90.207:8084/' });

}).listen(3600,function(){
    console.log('3600 代理启动成功!')
});

http.createServer(function(req, res) {
  // 你可以在这里添加处理逻辑
  // proxy.web(req, res, { target: 'http://140.99.86.171:8281/' });
  // proxy.web(req, res, { target: 'http://120.79.90.207:8084/' });

  res.end('0ok')

}).listen(3600,function(){
    console.log('3600 代理启动成功!')
});




 