var request = require("request");
var iconv = require('iconv-lite');
var Promise = require("bluebird");
var { exec } = require('child_process');
const http = require('http')

function getProxyList() {
    var apiURL = 'http://www.66ip.cn/mo.php?sxb=&tqsl=100&port=&export=&ktip=&sxa=&submit=%CC%E1++%C8%A1&textarea=http%3A%2F%2Fwww.66ip.cn%2F%3Fsxb%3D%26tqsl%3D100%26ports%255B%255D2%3D%26ktip%3D%26sxa%3D%26radio%3Dradio%26submit%3D%25CC%25E1%2B%2B%25C8%25A1';

    return new Promise((resolve, reject) => {
        var options = {
            method: 'GET',
            url: apiURL,
            // proxy: '<ip>:<port>',
            gzip: true,
            encoding: null,
            headers: {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Encoding': 'gzip, deflate',
                'Accept-Language': 'zh-CN,zh;q=0.8,en;q=0.6,zh-TW;q=0.4',
                'User-Agent': 'Mozilla/8.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36',
                'referer': 'http://www.66ip.cn/'
            },

        };

        // resolve(options)

        request(options, function (error, response, body) {
            try {
                // console.log(body.toString().match(/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,4}/g));
                // resolve(body.toString().match(/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,4}/g))
                resolve(`184.174.25.115:6004
23.236.222.201:7232
104.168.25.215:5897
206.41.169.253:5833
38.170.162.155:7210
137.59.7.179:5723
104.239.2.210:6513
140.99.51.133:8611
140.99.86.171:8281
154.85.100.212:5253
104.239.3.9:5969
104.239.10.117:5788
104.239.43.217:5945
172.245.158.106:6059
216.173.79.155:6561
107.172.163.69:6585
45.251.63.228:6300
134.73.94.126:6096
154.194.8.133:5664
194.39.34.159:6171
104.223.254.118:5707
104.233.13.131:6126
156.238.9.202:7093
23.247.37.33:6335
23.247.112.167:6823
140.99.47.6:8348
45.192.141.156:5193
45.249.104.37:6332
38.170.176.183:5578
45.192.141.229:5266
109.207.130.237:8244
64.137.108.242:5835
104.223.171.212:6503
23.247.101.179:6918
45.41.179.105:6640
64.137.103.216:6804
104.239.78.178:6123
140.99.55.173:8133
198.105.101.68:5697
45.12.140.50:5629
198.46.137.184:6388
43.229.11.166:5804
104.239.2.191:6494
216.173.76.0:6627
107.181.132.22:6000
5.154.254.112:5123
45.15.153.196:6154
172.245.7.71:5124
103.75.228.147:6226
134.73.52.193:6853
45.15.153.64:6313
104.239.2.235:6538
5.157.130.5:8009
38.154.206.228:9719
104.239.5.54:6708
23.247.112.117:6773
45.192.140.43:6633
64.137.66.229:5814 
104.239.106.38:5683
104.239.6.99:6233
138.128.145.92:6011
198.23.147.117:5132
45.43.177.82:6410
140.99.92.173:9280
178.159.34.218:6165
156.238.5.185:5526
184.174.25.27:5916
104.250.200.78:6328
45.192.156.225:6896
45.249.104.131:6426
104.143.229.25:5953
140.99.141.243:8852
198.46.246.61:6685
38.153.133.226:9630
64.137.18.135:6329
104.239.42.197:6222
104.239.37.114:5766
194.31.162.147:7663
64.137.108.200:5793
104.143.224.182:6043
45.43.190.80:6598
23.236.170.224:9257
45.89.105.190:7705
23.247.101.224:6963
45.43.82.227:6221
107.181.148.235:6095
38.154.195.8:9096
45.88.163.181:5961
103.75.230.187:6578
104.222.187.75:6199
104.239.22.64:6442
161.123.152.83:6328
104.239.97.15:5768
45.43.83.135:6418
188.68.1.12:5881
104.239.43.135:5863 
107.181.132.5:5983 
216.173.88.58:6407
134.73.94.113:6083`.split('\n'))
            } catch (e) {
                reject([])
            }
            //     try {
            //         if (error){
            //             throw new Error('出错啦!')
            //         };
            //         if (/meta.*charset=gb2312/.test(body)) {
            //             body = iconv.decode(body, 'gbk');
            //         }
            //         var ret = body.match(/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,4}/g);
            //         resolve(ret);
            //     } catch (e) {
            //         return reject(e);
            //     }
        });
    })
}





http.createServer(function (req, res) {
    // 你可以在这里添加处理逻辑
    // proxy.web(req, res, { target: 'http://140.99.86.171:8281/' });
    // proxy.web(req, res, { target: 'http://120.79.90.207:8084/' });

    getProxyList().then(function (proxyList) {

        var targetOptions = {
            method: 'GET',
            // url: 'http://myip.ipip.net',
            // url: 'https://www.facebook.com',
            url: 'https://www.youtube.com',
            // url: 'https://github.com',
            // url: 'http://Wikipedia.org',
            timeout: 8000,
            encoding: null,
            headers: {
                'Proxy-Authorization': 'Basic ' + Buffer.from('qwe1qwe1qwe1:qwe1qwe1qwe1', 'utf-8').toString('base64')
            }
        };
        // console.log(proxyList, 'libiao')

        //这里修改一下，变成你要访问的目标网站
        Array.isArray(proxyList) && proxyList.slice(0, 50).forEach(function (proxyurl,idx) {
            targetOptions.proxy = 'http://' + proxyurl.trim();
            // const code = `curl --socks5 qwe1qwe1qwe1:qwe1qwe1qwe1@${proxyurl.trim().replace(/\n|\r|t/g, '')} --proxy-ntlm http://myip.ipip.net`;
            const code = `curl --socks5 qwe1qwe1qwe1:qwe1qwe1qwe1@${proxyurl.trim().replace(/\n|\r|t/g, '')} --proxy-ntlm https://www.youtube.com`;
            // console.log(code);
            request(targetOptions, function (error, response, body) {
                try {
                    if (body) {
                        body = body.toString();
                        // console.log(body, targetOptions.proxy);
                        console.log('有效的ip', targetOptions.proxy);
                        res.end(body);
                    } else {
                        // console.log(response,error)
                    }
                    // eval(`var ret = ${body}`);
                    // if (ret) {
                    //     console.log(`验证成功==>> ${ret.address}`);
                    // }
                } catch (e) {
                    console.error('失败了哟!', e, targetOptions.headers);
                }
            });
        });
    }).catch(e => {
        console.log(e, '代理认证失败！');
    })

}).listen(3600, function () {
    console.log('3600 代理启动成功!')
});

