const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');

var  list = [
    'https://web.telegram.org/css/app.css',
    'https://web.telegram.org/manifest.webapp.json',
    'https://web.telegram.org/favicon.ico',
    'https://web.telegram.org/img/iphone_home120.png',
    'https://web.telegram.org/img/iphone_home120.png',
    'https://web.telegram.org/img/iphone_startup.png',
    'https://web.telegram.org/js/app.js'
]

function downloadFile(fileUrl) {
    const parsedUrl = url.parse(fileUrl);
    const filePath = parsedUrl.pathname.split('/').slice(3, -1).join('/');
    const fileName = path.basename(parsedUrl.pathname).split('?')[0];
    const folderPath = path.join(__dirname, 'recipes', 'telegram', filePath);
    const filePathOnDisk = path.join(folderPath, fileName);
    const protocol = fileUrl.startsWith('https') ? https : http;
    // 创建文件夹
    fs.mkdirSync(folderPath, { recursive: true });
    // 发送GET请求获取文件内容
    protocol.get(fileUrl, {
        // proxy:"http://104.239.3.9:5969",
        headers: {
            'Proxy-Authorization': 'Basic ' + Buffer.from('qwe1qwe1qwe1:qwe1qwe1qwe1', 'utf-8').toString('base64'),
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'
        }
    }, (response) => {
        const fileStream = fs.createWriteStream(filePathOnDisk);
        response.pipe(fileStream);
        fileStream.on('finish', () => {
            fileStream.close();
            console.log(`文件已下载到 ${filePathOnDisk}`);
        });
    }).on('error', (err) => {
        console.error(`下载文件时遇到错误: ${err.message}`);
    });
}
// 使用示例
const fileUrl = 'https://img.iplaysoft.com/wp-content/uploads/2019/free-images/free_stock_photo.jpg!0x0.webp';
downloadFile(list.shift());

